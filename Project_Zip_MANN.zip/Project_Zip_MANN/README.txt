Carmen Mann
Final Project for COP2073

Items in Folder:
Data: Contains both the .csv file of the data to be analyzed as well as a README.txt document explaining the data.
Proposal: Contains the initial analytical proposal.
Project: The report itself. Contains analysis as well as visualizations of the data.
Presentation: A presentation version of the report. Contains further analysis on visualizations, easily digestible for a wider audience.

Link to GitHub repo: https://github.com/macabreplaza/COP2073Final_MANN