Carmen Mann
10/29/2024


1. Link to dataset: https://www.kaggle.com/datasets/akhilv11/border-crossing-entry-data

2. Summary:
This is a 5 year old data set with 7 variables and 349000 observations. It includes information about the US-Canada border as well as the US-Mexico border.
Contains data that is categorical (State) as well as data that is numerical. (# Value)
Contains data with an abnormal categorization (location is recorded in longitude and latitude).

